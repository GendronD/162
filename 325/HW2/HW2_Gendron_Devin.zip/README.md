HW 2 README FIle.

Please note, I've included a makefile for convenience - however, it compiles files as so:

	g++ -g -std=c++0x stoogesort.o -o stoogesort.o

I've tested stoogesort using only g++ and it works according to the homeworks specifications. So, 

	g++ stoogesort.cpp -o stoogesort.o

works without issue.

Files included:

	stoogesort.cpp

	makefile
	README.md

If you experience any issues, please send me an email and I'll address them as soon as possible.

EMAIL: gendrond@oregonstate.edu
	   gendron.devin@gmail.com