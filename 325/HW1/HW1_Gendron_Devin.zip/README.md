HW 1 README FIle.

Please note, I've included a makefile for convenience - however, it compiles files as so:

	g++ -g -std=c++0x insertsort.o -o insertsort.o

I've tested both of my mergesort.cpp and insertsort.cpp files using only g++ and they work
according to the homeworks specifications. Thus, the file I/O works on flip just with g++ as well as the other files.

Files included:

	insertsort.cpp
	insertTime.cpp
	insertTimeBest.cpp (EC)
	insertTimeWorst.cpp (EC)

	mergesort.cpp
	mergeTime.cpp
	mergeTimeBest.cpp (EC)
	mergeTimeWorst.cpp (EC)

	makefile
	README.md

Also note, my programs are set to run one size of n at a time.  To collect multiple readings from insertTime.cpp and mergeTime.cpp, you will need to rerun them.

If you experience any issues, please send me an email and I'll address them as soon as possible.

EMAIL: gendrond@oregonstate.edu
	   gendron.devin@gmail.com