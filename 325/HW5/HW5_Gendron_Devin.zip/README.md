HW 5 README FIle.

Please note, I've included a makefile for convenience - however, it compiles files as so:

	g++ -g -std=c++0x wrestler.o -o wrestler

I've tested change.cpp using only g++ and it works according to the homeworks specifications. So, 

	g++ wrestler.cpp -o wrestler

works without issue.

I've tested the file to work using the text files indicated below as such:

	./wrestler wrestler.txt
	./wrestler wrestler1.txt
	./wrestler wrestler2.txt

Files included:

	wrestler.cpp
	wrestler.txt
	wrestler1.txt
	wrestler2.txt

	makefile
	README.md


If you experience any issues, please send me an email and I'll address them as soon as possible.

EMAIL: gendrond@oregonstate.edu
	   gendron.devin@gmail.com