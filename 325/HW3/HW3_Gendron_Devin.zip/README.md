HW 3 README FIle.

Please note, I've included a makefile for convenience - however, it compiles files as so:

	g++ -g -std=c++0x change.o -o change

I've tested change.cpp using only g++ and it works according to the homeworks specifications. So, 

	g++ change.cpp -o change.o

works without issue.

Files included:

	change.cpp
	amount.txt

	makefile
	README.md

This file will output a file titled, "change.txt".

If you experience any issues, please send me an email and I'll address them as soon as possible.

EMAIL: gendrond@oregonstate.edu
	   gendron.devin@gmail.com