HW 4 README FIle.

Please note, I've included a makefile for convenience - however, it compiles files as so:

	g++ -g -std=c++0x act.o -o act

I've tested change.cpp using only g++ and it works according to the homeworks specifications. So, 

	g++ act.cpp -o act

works without issue.

Files included:

	act.cpp
	act.txt

	makefile
	README.md


If you experience any issues, please send me an email and I'll address them as soon as possible.

EMAIL: gendrond@oregonstate.edu
	   gendron.devin@gmail.com