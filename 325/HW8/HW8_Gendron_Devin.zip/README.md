HW 8 README FIle.

I've tested bin.cpp using only g++ and it works according to the homeworks specifications. So, 

	g++ bin.cpp -o bin

works without issue.

Files included:

	bin.cpp
	bin.txt
	partC.txt

	README.md


If you experience any issues, please send me an email and I'll address them as soon as possible.

EMAIL: gendrond@oregonstate.edu
	   gendron.devin@gmail.com